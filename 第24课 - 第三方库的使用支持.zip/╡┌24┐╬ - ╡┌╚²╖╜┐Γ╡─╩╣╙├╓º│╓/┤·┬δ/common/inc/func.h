#ifndef FUNC_H
#define FUNC_H

void foo();

#endif
