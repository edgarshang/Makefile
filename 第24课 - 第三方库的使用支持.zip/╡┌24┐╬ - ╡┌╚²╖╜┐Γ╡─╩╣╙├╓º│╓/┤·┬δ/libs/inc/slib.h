

char* slib_name();
int multi(int a, int b);
