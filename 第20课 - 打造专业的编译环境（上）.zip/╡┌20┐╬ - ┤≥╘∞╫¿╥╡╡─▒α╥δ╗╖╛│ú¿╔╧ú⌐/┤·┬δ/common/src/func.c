#include <stdio.h>
#include "func.h"

void foo()
{
    printf("void foo()::%s\n", "Hello, D.T.Software ...");
}
